// p.28 Timeouts

package main

import "fmt"

func main(){
}
