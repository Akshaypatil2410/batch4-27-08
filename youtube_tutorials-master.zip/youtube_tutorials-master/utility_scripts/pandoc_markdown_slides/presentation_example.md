% Title of Talk 
% Speaker Name
% Date of Talk

# Title of Slide
This is a slide.

# Title of Slide 2

- Item of list 
- Another item of list 
- Etc.

# Title of Slide 3

$$ \sum_{a,b} + x y \infty $$

# Title of Slide 4

- *This text is in italics*
- **This text is in bold**
- ~~This text has a line through it~~

# Title of Slide 5

![This is the caption of the figure.](test_image.PNG)
