YouTube Video: https://www.youtube.com/watch?v=H4irPAcf940
% Channel Update
% December 2017

# Thank you!

A sincere and heartfelt thank you to my subscribers!

# Brief Channel Update

-What to expect moving forward.


# Content for 2018

(Link in description):
https://goo.gl/forms/BU8QcUzDy1MslDC73 

# Have a great New Year!


