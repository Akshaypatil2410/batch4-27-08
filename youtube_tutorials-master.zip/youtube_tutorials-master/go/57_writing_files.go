// p.57 Writing Files

package main

import "fmt"

func main(){
}
