// YouTube Video: https://www.youtube.com/watch?v=wqANpSRmlm4&t=0s&list=PL5tcWHG-UPH0jOCtEIpDNpbwOnhc6h9Om
// p3. Variables
package main

import "fmt"

func main() {
    var num_items int = 100

    //var price1 float64 = 9.99
    //var price2 float64 = 5.50

    //var price1, price2 float64 = 9.99, 5.50

    price1, price2 := 9.99, 5.50

    var s = "Hello"
    fmt.Println(s)

    fmt.Println(num_items)
    fmt.Println(price1)
    fmt.Println(price2)
}
