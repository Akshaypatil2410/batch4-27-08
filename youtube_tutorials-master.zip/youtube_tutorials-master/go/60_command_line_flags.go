// p.60 Command Line Flags

package main

import "fmt"

func main(){
}
