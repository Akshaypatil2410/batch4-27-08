// p.49 Epoch

package main

import "fmt"

func main(){
}
