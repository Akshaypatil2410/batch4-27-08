// p.59 Command Line Arguments

package main

import "fmt"

func main(){
}
