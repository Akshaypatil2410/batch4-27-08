// p.56 Reading Files

package main

import "fmt"

func main(){
}
