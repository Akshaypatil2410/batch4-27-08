// p.24 Channel Buffering

package main

import "fmt"

func main(){
}
