// p.22 GoRoutines

package main

import "fmt"

func main(){
}
