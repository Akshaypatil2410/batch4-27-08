// p.53 URL Parsing

package main

import "fmt"

func main(){
}
