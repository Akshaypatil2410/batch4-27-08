// p.35 Rate Limiting

package main

import "fmt"

func main(){
}
