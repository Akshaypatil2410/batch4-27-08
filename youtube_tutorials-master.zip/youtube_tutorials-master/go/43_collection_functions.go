// p.43 Collection Functions

package main

import "fmt"

func main(){
}
