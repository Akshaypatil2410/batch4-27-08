// p.65 Exit

package main

import "fmt"

func main(){
}
