// p.42 Defer

package main

import "fmt"

func main(){
}
