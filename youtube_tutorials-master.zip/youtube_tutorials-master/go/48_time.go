// p.48 Time

package main

import "fmt"

func main(){
}
