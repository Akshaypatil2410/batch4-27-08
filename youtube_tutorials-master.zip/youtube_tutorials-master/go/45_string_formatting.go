// p.45 String Formatting

package main

import "fmt"

func main(){
}
