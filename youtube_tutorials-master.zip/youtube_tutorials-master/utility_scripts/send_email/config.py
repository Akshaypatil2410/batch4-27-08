# YouTube Video: https://www.youtube.com/watch?v=mP_Ln-Z9-XY
EMAIL_ADDRESS = ""
PASSWORD = ""
