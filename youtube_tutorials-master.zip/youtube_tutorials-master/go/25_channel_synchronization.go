// p.25 Channel Synchronization

package main

import "fmt"

func main(){
}
