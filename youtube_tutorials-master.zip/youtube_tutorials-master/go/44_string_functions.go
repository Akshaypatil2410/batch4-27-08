// p.44 String Functions

package main

import "fmt"

func main(){
}
