// p.29 Nonblocking Channel Operations

package main

import "fmt"

func main(){
}
