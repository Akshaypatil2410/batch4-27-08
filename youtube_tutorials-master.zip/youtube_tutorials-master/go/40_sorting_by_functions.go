// p.40 Sorting by Functions

package main

import "fmt"

func main(){
}
