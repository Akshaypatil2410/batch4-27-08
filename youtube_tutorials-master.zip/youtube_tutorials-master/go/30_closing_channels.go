// p.30 Closing Channels

package main

import "fmt"

func main(){
}
