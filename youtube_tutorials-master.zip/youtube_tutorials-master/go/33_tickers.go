// p.33 Tickers

package main

import "fmt"

func main(){
}
