// p.39 Sorting

package main

import "fmt"

func main(){
}
