// p.52 Number Parsing

package main

import "fmt"

func main(){
}
