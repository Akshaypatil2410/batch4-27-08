// p.27 Select

package main

import "fmt"

func main(){
}
