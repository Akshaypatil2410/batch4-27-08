// p.46 Regular Expressions

package main

import "fmt"

func main(){
}
