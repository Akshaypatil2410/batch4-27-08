// p.51 Random Numbers

package main

import "fmt"

func main(){
}
