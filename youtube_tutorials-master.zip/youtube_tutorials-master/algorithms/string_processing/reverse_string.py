# YouTube Link:
"""
Given a string with a set of words separated by whitespace,
reverse the order of the words.
Example:

    Initial String:
    this is a string reversal problem

    Resulting String:
    problem reversal string a is this
"""


def reverse_words(s):
    pass


