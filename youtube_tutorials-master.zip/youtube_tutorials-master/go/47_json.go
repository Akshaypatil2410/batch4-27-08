// p.47 JSON

package main

import "fmt"

func main(){
}
