# YouTube Link:
"""
Write a function that converts Roman numerals to decimal numbers.

Example:
    I -> 1
    II -> 2
    V -> 5
    IX -> 9
    CM -> 900
    etc.
"""


def roman_numeral_to_decimal(roman_numeral):
    """Converts a roman numeral to a decimal number."""
    pass


