// p.26 Channel Directions

package main

import "fmt"

func main(){
}
