% Channel Update
% January 2018

# Thank you!

-500 subscriber milestone.

-A sincere and heartfelt thank you to my subscribers!


# Brief Channel Update

-Natural language processing videos

-Twitter API and Python videos

-Data structures and Algorithms in Python (Recursion, Linked Lists, etc.)


# YouTube Partner Program Updates

- YouTube has changed their partnership guidelines.

- If you find the content here valuable and are not already, please consider subscribing.


# Live Streaming Ideas

- Once 1000 subscriptions, the ability to livestream becomes active. 

- Solve programming challenges live (i.e. HackerRank)

- Play video games and talk code, Q&A, etc?

- Any other ideas welcome!


