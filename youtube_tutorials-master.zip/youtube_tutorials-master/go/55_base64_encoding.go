// p.55 Base64 Encoding

package main

import "fmt"

func main(){
}
