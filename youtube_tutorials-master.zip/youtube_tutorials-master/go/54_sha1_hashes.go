// p.54 SHA1 Hashes

package main

import "fmt"

func main(){
}
