// p.34 Worker Pools

package main

import "fmt"

func main(){
}
