// p.62 Spawning Processes

package main

import "fmt"

func main(){
}
