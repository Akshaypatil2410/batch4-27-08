// p.37 Mutexes

package main

import "fmt"

func main(){
}
