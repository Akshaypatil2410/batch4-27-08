# YouTube Video: https://www.youtube.com/watch?v=CXtC8Jzxsvw
import pyautogui
pyautogui.click((pyautogui.locateCenterOnScreen('auxillary_files/1key.png')))
pyautogui.click((pyautogui.locateCenterOnScreen('auxillary_files/pluskey.png')))
pyautogui.click((pyautogui.locateCenterOnScreen('auxillary_files/1key.png')))
pyautogui.press('enter')
