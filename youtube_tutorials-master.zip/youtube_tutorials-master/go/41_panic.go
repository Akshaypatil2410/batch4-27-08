// p.41 Panic

package main

import "fmt"

func main(){
}
