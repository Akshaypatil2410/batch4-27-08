// p.64 Signals

package main

import "fmt"

func main(){
}
