// p.32 Timers

package main

import "fmt"

func main(){
}
