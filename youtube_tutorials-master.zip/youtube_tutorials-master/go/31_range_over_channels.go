// p.31 Range Over Channels

package main

import "fmt"

func main(){
}
