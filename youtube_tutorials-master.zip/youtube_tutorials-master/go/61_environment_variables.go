// p.61 Environment Variables

package main

import "fmt"

func main(){
}
