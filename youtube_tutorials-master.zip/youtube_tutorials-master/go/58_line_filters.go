// p.58 Line Filters

package main

import "fmt"

func main(){
}
