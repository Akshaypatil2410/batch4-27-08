// YouTube Video: https://www.youtube.com/watch?v=mbW0oQq5NLQ&t=0s&list=PL5tcWHG-UPH0jOCtEIpDNpbwOnhc6h9Om
// p1. Hello World
package main

import "fmt"

func main() {
    fmt.Println("hello world")
}
