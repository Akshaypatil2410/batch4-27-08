// p.50 Time Formatting

package main

import "fmt"

func main(){
}
