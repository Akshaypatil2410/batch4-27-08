// p.36 Atomic Counters

package main

import "fmt"

func main(){
}
