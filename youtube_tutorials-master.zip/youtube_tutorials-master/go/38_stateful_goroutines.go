// p.38 Stateful GoRoutines

package main

import "fmt"

func main(){
}
