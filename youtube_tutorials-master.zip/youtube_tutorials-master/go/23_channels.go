// p.23 Channels

package main

import "fmt"

func main(){
}
